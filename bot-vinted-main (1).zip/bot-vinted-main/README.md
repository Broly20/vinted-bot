Nouvelle version :

-Ajout d'une fonctionnalité pour envoyer un message au vendeur
![image](![image](https://user-images.githubusercontent.com/99037050/153257457-3b735464-70e3-4ba7-b21a-4d8eb22f8af9.png)



-Ajout de la fonctionnalité random sur les embeds
                                              ![image](https://user-images.githubusercontent.com/99037050/153257656-d97de531-ce99-4b24-995d-9f6c7e9b8687.png)


-Lancer le fichier run pour installer les modules nécessaires






-Vidéos pour expliquer comment cela fonctionne : 
https://www.youtube.com/watch?v=PM7ZGmpvm8c




